"""
LLM Service integration supporting Google Gemini API with fallback.
Handles prompt construction, token tracking, cost estimation, and structured JSON output.
"""

import json
import os
import time
from typing import Dict, Any, Optional, Tuple
from app.config import (
    GEMINI_API_KEY, LLM_MODEL_NAME,
    ESTIMATED_PROMPT_TOKEN_COST_PER_M, ESTIMATED_COMPLETION_TOKEN_COST_PER_M
)


def calculate_cost(prompt_tokens: int, completion_tokens: int) -> float:
    """Computes estimated query cost in USD."""
    prompt_cost = (prompt_tokens / 1_000_000.0) * ESTIMATED_PROMPT_TOKEN_COST_PER_M
    completion_cost = (completion_tokens / 1_000_000.0) * ESTIMATED_COMPLETION_TOKEN_COST_PER_M
    return round(prompt_cost + completion_cost, 6)


class LLMService:
    def __init__(self, api_key: str = GEMINI_API_KEY, model_name: str = LLM_MODEL_NAME):
        self.api_key = api_key
        self.model_name = model_name
        self.client = None
        self._init_client()

    def _init_client(self):
        """Initializes google-genai client if API key is present."""
        if self.api_key:
            try:
                from google import genai
                self.client = genai.Client(api_key=self.api_key)
            except Exception as e:
                # If library not present or init fails, will use rule-based fallback
                self.client = None

    def generate_plan(self, query: str, siis_text: str) -> Tuple[Optional[Dict[str, Any]], Dict[str, Any]]:
        """
        Executes LLM extraction against SIIS knowledge text.
        Returns (parsed_json_dict, usage_meta).
        """
        start_time = time.perf_counter()
        
        # If no client or no key, return None to trigger deterministic rule extractor
        if not self.client:
            return None, {
                "model": "deterministic-siis-extractor",
                "prompt_tokens": 0,
                "completion_tokens": 0,
                "cost_usd": 0.0,
                "latency_ms": (time.perf_counter() - start_time) * 1000.0
            }

        prompt = f"""You are a Samsung Galaxy Technical Support Diagnostic Engine.
Given the customer query and the reference SIIS support text below, extract a strictly structured troubleshooting plan.

STRICT CONSTRAINTS:
1. Pure JSON output only. No markdown formatting, no code fences (```json), no conversational text.
2. The goal field MUST strictly follow: "Follow these steps to perform this <Topic> Troubleshooting"
3. The title field MUST be 2 to 3 words, sentence case.
4. description MUST be exactly 5 to 7 words, starting with "It will", explaining the concrete benefit.
5. actionName MUST be Title Case and represent exactly ONE physical screen. Group all steps on that screen together.
6. category MUST be one of: "auto", "manual", "critical". Critical operations (restart, reset, firmware) must be placed last.
7. Absolute prohibition of web URLs (no http, https, www).
8. If the reference text does NOT contain a solution, return {{"contexts": []}}.

Customer Query: {query}
Reference SIIS Text: {siis_text}
"""
        try:
            response = self.client.models.generate_content(
                model=self.model_name,
                contents=prompt,
                config={
                    "response_mime_type": "application/json"
                }
            )
            raw_text = response.text.strip()
            # Programmatically clean markdown if present
            if raw_text.startswith("```"):
                raw_text = raw_text.strip("`")
                if raw_text.startswith("json"):
                    raw_text = raw_text[4:].strip()

            parsed = json.loads(raw_text)
            prompt_tokens = getattr(response.usage_metadata, "prompt_token_count", 250)
            completion_tokens = getattr(response.usage_metadata, "candidates_token_count", 180)
            cost = calculate_cost(prompt_tokens, completion_tokens)
            
            return parsed, {
                "model": self.model_name,
                "prompt_tokens": prompt_tokens,
                "completion_tokens": completion_tokens,
                "cost_usd": cost,
                "latency_ms": (time.perf_counter() - start_time) * 1000.0
            }
        except Exception:
            return None, {
                "model": "deterministic-siis-extractor-fallback",
                "prompt_tokens": 0,
                "completion_tokens": 0,
                "cost_usd": 0.0,
                "latency_ms": (time.perf_counter() - start_time) * 1000.0
            }
