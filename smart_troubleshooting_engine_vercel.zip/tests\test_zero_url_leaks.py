"""
Unit test: Absolute Prohibition of Web URLs (Zero URL Leaks).
"""

import unittest
from app.engine.validators import scrub_urls, URL_PATTERN


class TestZeroUrlLeaks(unittest.TestCase):
    def test_scrub_https_urls(self):
        dirty = "Open browser at https://samsung.com/support and tap settings."
        clean = scrub_urls(dirty)
        self.assertNotIn("https://", clean)
        self.assertNotIn("samsung.com", clean)

    def test_scrub_www_urls(self):
        dirty = "Visit www.samsung.com/galaxy-help to download firmware."
        clean = scrub_urls(dirty)
        self.assertNotIn("www.", clean)

    def test_scrub_markdown_links(self):
        dirty = "Check [Samsung Support Guide](https://support.samsung.com) for troubleshooting."
        clean = scrub_urls(dirty)
        self.assertNotIn("https://", clean)
        self.assertIn("Samsung Support Guide", clean)

    def test_zero_leak_regex_guarantee(self):
        sample = "Go to http://help.example.com and check www.example.org now."
        clean = scrub_urls(sample)
        matches = URL_PATTERN.findall(clean)
        self.assertEqual(len(matches), 0)


if __name__ == "__main__":
    unittest.main()
