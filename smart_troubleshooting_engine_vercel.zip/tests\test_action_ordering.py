"""
Unit test: Action Hierarchy & Sequencing.
Verifies that:
- auto (safe settings) appears first
- manual appears second
- critical (reboots, factory resets) is strictly ordered LAST.
"""

import unittest
from app.schema import Action, StepGroup, actionCategory
from app.engine.sequencer import order_actions


class TestActionOrdering(unittest.TestCase):
    def test_sequencing_order(self):
        act_critical = Action(
            actionName="Restart Phone To Clear State",
            description="It will reboot device system processes",
            category=actionCategory.critical,
            stepGroups=[]
        )
        act_auto = Action(
            actionName="Optimize Memory In Device Care",
            description="It will clear device memory cache",
            category=actionCategory.auto,
            stepGroups=[]
        )
        act_manual = Action(
            actionName="Inspect Charging Port Physically",
            description="It will verify port physical integrity",
            category=actionCategory.manual,
            stepGroups=[]
        )

        # Pass in unordered list
        unordered = [act_critical, act_manual, act_auto]
        ordered = order_actions(unordered)

        self.assertEqual(ordered[0].category, actionCategory.auto)
        self.assertEqual(ordered[1].category, actionCategory.manual)
        self.assertEqual(ordered[2].category, actionCategory.critical)


if __name__ == "__main__":
    unittest.main()
