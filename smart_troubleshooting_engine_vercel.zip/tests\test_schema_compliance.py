"""
Unit test: 100% Schema Conformance to Appendix A and strict rule constraints.
"""

import unittest
from app.schema import Goal, Action, StepGroup, actionCategory, ContextDeeplinkResponse, Deeplink
from app.engine.validators import normalize_goal, normalize_title, normalize_description, validate_and_correct_goal


class TestSchemaCompliance(unittest.TestCase):
    def test_goal_syntax_enforcement(self):
        # Must follow: Follow these steps to perform this <Topic> Troubleshooting
        raw_goal = "Fix navigation buttons"
        normalized = normalize_goal(raw_goal, topic="Navigation")
        self.assertTrue(normalized.startswith("Follow these steps to perform this "))
        self.assertTrue(normalized.endswith("Troubleshooting") or normalized.endswith("Configuration"))

    def test_title_word_count(self):
        # 2 to 3 words, sentence case
        raw_title = "The super long title describing battery drain completely"
        normalized = normalize_title(raw_title)
        words = normalized.split()
        self.assertTrue(2 <= len(words) <= 3)
        self.assertTrue(normalized[0].isupper())

    def test_description_constraint(self):
        # Exactly 5 to 7 words, starting with 'It will'
        desc = normalize_description("adjusts dynamic refresh rate efficiently", "Motion smoothness")
        words = desc.split()
        self.assertEqual(words[0], "It")
        self.assertEqual(words[1], "will")
        self.assertTrue(5 <= len(words) <= 7, f"Description '{desc}' has {len(words)} words, expected 5-7")

    def test_pydantic_model_serialization(self):
        sg = StepGroup(
            steps=["Navigate to Settings.", "Tap Display."],
            actionableDeeplink=Deeplink(
                deeplink="bixby://masked/act/display/smoothness",
                description="Open Motion smoothness settings under Display"
            )
        )
        action = Action(
            actionName="Adjust Motion Smoothness",
            description="It will stabilize display refresh rate",
            category=actionCategory.auto,
            stepGroups=[sg]
        )
        goal = Goal(
            goal="Follow these steps to perform this Display Troubleshooting",
            title="Display flicker fix",
            actions=[action],
            score=0.95
        )
        response = ContextDeeplinkResponse(contexts=[goal])
        data = response.model_dump()
        self.assertIn("contexts", data)
        self.assertEqual(data["contexts"][0]["actions"][0]["category"], "auto")


if __name__ == "__main__":
    unittest.main()
