"""
Launcher script for Samsung Smart Guided Troubleshooting Engine.
Starts the FastAPI application with Uvicorn.
"""

import sys
import uvicorn
from pathlib import Path

# Add project root to sys.path
PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))


def main():
    print("==================================================================")
    print("Starting Samsung Smart Guided Troubleshooting Engine...")
    print("API Endpoints:")
    print("  - Web Playground:   http://localhost:8000")
    print("  - API Endpoint:     http://localhost:8000/v1/troubleshoot")
    print("  - Health Check:     http://localhost:8000/health")
    print("  - Swagger Docs:     http://localhost:8000/docs")
    print("==================================================================")
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)


if __name__ == "__main__":
    main()
