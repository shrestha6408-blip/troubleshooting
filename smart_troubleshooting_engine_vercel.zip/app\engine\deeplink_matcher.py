"""
Deeplink Catalog Indexer and Semantic Matcher.
Matches action and step descriptions to masked Settings deeplinks.
Integrates BM25-style keyword matching and semantic n-gram overlap.
Enforces Catalog Integrity and prevents parent-menu false positives.
"""

import json
import math
import re
from typing import Dict, List, Optional, Tuple
from app.config import DEEPLINKS_FILE
from app.schema import Deeplink

DUMMY_POSITIVE_URI = "bixby://dummy_positive"


class DeeplinkCatalog:
    _instance = None

    def __init__(self, catalog_path=DEEPLINKS_FILE):
        self.catalog_path = catalog_path
        self.items: List[Dict] = []
        self.indexed_terms: Dict[str, List[int]] = {}
        self.doc_lengths: List[int] = []
        self.avg_doc_len: float = 0.0
        self.load_catalog()

    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def load_catalog(self):
        """Load deeplinks catalog and build BM25 search index."""
        if not self.catalog_path.exists():
            self.items = []
            return

        with open(self.catalog_path, "r", encoding="utf-8") as f:
            self.items = json.load(f)

        # Build term index across metadata fields (description, message, qna_description)
        total_tokens = 0
        self.doc_lengths = []
        self.indexed_terms = {}

        for idx, item in enumerate(self.items):
            # Do NOT index the masked URI string itself to prevent superficial token matching
            corpus_text = f"{item.get('description', '')} {item.get('message', '')} {item.get('qna_description', '')}"
            tokens = self._tokenize(corpus_text)
            self.doc_lengths.append(len(tokens))
            total_tokens += len(tokens)

            for token in set(tokens):
                if token not in self.indexed_terms:
                    self.indexed_terms[token] = []
                self.indexed_terms[token].append(idx)

        self.avg_doc_len = total_tokens / max(1, len(self.items))

    def _tokenize(self, text: str) -> List[str]:
        cleaned = re.sub(r'[^a-zA-Z0-9\s]', ' ', text.lower())
        return [t for t in cleaned.split() if len(t) > 1]

    def match_deeplink(self, action_name: str, steps: List[str]) -> Optional[Deeplink]:
        """
        Finds the best matching deeplink from the catalog for a given action and steps.
        Avoids parent-menu matches by scoring specific sub-screen terms higher.
        """
        if not self.items:
            return None

        # Build query text from action name (weighted 2x) and steps
        query_text = f"{action_name} {action_name} " + " ".join(steps)
        query_tokens = self._tokenize(query_text)

        if not query_tokens:
            return None

        k1 = 1.5
        b = 0.75
        num_docs = len(self.items)
        scores: Dict[int, float] = {}

        for token in query_tokens:
            if token in self.indexed_terms:
                doc_list = self.indexed_terms[token]
                df = len(doc_list)
                # BM25 IDF
                idf = math.log((num_docs - df + 0.5) / (df + 0.5) + 1.0)

                for doc_idx in doc_list:
                    # Term frequency in doc
                    item = self.items[doc_idx]
                    doc_text = f"{item.get('description', '')} {item.get('message', '')} {item.get('qna_description', '')}".lower()
                    tf = doc_text.count(token)
                    doc_len = self.doc_lengths[doc_idx]
                    tf_norm = (tf * (k1 + 1)) / (tf + k1 * (1 - b + b * (doc_len / self.avg_doc_len)))
                    
                    scores[doc_idx] = scores.get(doc_idx, 0.0) + (idf * tf_norm)

        if not scores:
            return None

        # Filter out generic placeholder from normal ranking
        sorted_indices = sorted(scores.keys(), key=lambda i: scores[i], reverse=True)
        best_idx = None
        best_score = 0.0

        for idx in sorted_indices:
            uri = self.items[idx].get("deeplink", "")
            if uri == DUMMY_POSITIVE_URI:
                continue
            best_idx = idx
            best_score = scores[idx]
            break

        # Confidence threshold: if score is too low or no match, evaluate if it's a valid settings action
        if best_idx is not None and best_score > 1.2:
            matched_item = self.items[best_idx]
            return Deeplink(
                deeplink=matched_item["deeplink"],
                description=matched_item.get("description", ""),
                message=matched_item.get("message", ""),
                classes=matched_item.get("classes"),
                originalType=matched_item.get("controlType")
            )

        # Check if steps indicate opening a Settings screen not explicitly in catalog -> use bixby://dummy_positive
        full_text = f"{action_name} {' '.join(steps)}".lower()
        if any(keyword in full_text for keyword in ["settings", "display", "battery", "camera", "apps", "device care"]):
            return Deeplink(
                deeplink=DUMMY_POSITIVE_URI,
                description=f"Open settings for {action_name}",
                message=f"configure {action_name}"
            )

        return None
