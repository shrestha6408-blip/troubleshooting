"""
Vercel Serverless Entrypoint for Smart Guided Troubleshooting Engine.
Exposes FastAPI 'app' instance for @vercel/python runtime.
"""

import sys
from pathlib import Path

# Add project root directory to sys.path so 'app' and 'data' are discoverable
ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from app.main import app

# Vercel entrypoint exposes 'app'
__all__ = ["app"]
