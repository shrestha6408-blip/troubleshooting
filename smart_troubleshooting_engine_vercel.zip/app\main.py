"""
FastAPI REST API Service for Smart Guided Troubleshooting Engine.
Exposes:
- POST /v1/troubleshoot (Compliant with Appendix B contract)
- GET /health
- Interactive Web Demo UI at /
"""

import time
from pathlib import Path
from fastapi import FastAPI, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles

from app.schema import TroubleshootRequest, TroubleshootResponse, ResponseMeta, ContextDeeplinkResponse
from app.cache.fast_cache import FastPathCache
from app.engine.pipeline import TroubleshootingPipeline

app = FastAPI(
    title="Samsung Smart Guided Troubleshooting Engine",
    description="Transforms vague Galaxy device complaints into deeplinked, one-tap troubleshooting plans in <300ms",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize singletons
cache = FastPathCache.get_instance()
pipeline = TroubleshootingPipeline()

STATIC_DIR = Path(__file__).resolve().parent / "static"
if STATIC_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


@app.get("/health", status_code=status.HTTP_200_OK)
def health_check():
    """
    Returns HTTP 200 {"status": "ok"} when caching layer,
    model connections, and indexes are fully initialized.
    """
    is_cache_ready = len(cache.exact_cache) > 0
    is_catalog_ready = len(pipeline.catalog.items) > 0
    if is_cache_ready and is_catalog_ready:
        return {"status": "ok"}
    return JSONResponse(
        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
        content={"status": "initializing", "cache_ready": is_cache_ready, "catalog_ready": is_catalog_ready}
    )


@app.post("/v1/troubleshoot", response_model=TroubleshootResponse)
def troubleshoot(payload: TroubleshootRequest):
    """
    Processes a customer complaint and returns an actionable plan.
    - If previously encountered or cached: returns in <300 ms with $0.00 cost.
    - If cold: runs query enrichment, structure extraction, deeplink mapping, and caches result.
    """
    start_time = time.perf_counter()
    query = payload.query.strip()

    if not query:
        raise HTTPException(status_code=400, detail="Query string cannot be empty.")

    # [3] Fast-Path Semantic Cache Check
    cached_result = cache.get(query)
    if cached_result is not None:
        cached_data, tier = cached_result
        elapsed_ms = (time.perf_counter() - start_time) * 1000.0
        
        return TroubleshootResponse(
            query=payload.query,
            query_variations=cached_data.get("query_variations", []),
            response=ContextDeeplinkResponse(**cached_data.get("response", {})),
            meta=ResponseMeta(
                latency_ms=round(elapsed_ms, 2),
                cache_hit=True,
                model="fast-path-cache-" + tier,
                cost_usd=0.0
            )
        )

    # [0]-[2] Cold Query Pipeline Execution
    result_dict, meta_dict = pipeline.process_query(query, payload.siis_response)

    # If valid contexts were found, store in cache for future hits
    if result_dict.get("response", {}).get("contexts"):
        cache.set(
            query=query,
            variations=result_dict.get("query_variations", []),
            response_data=result_dict.get("response", {})
        )

    total_latency_ms = (time.perf_counter() - start_time) * 1000.0

    return TroubleshootResponse(
        query=result_dict["query"],
        query_variations=result_dict.get("query_variations", []),
        response=ContextDeeplinkResponse(**result_dict.get("response", {})),
        meta=ResponseMeta(
            latency_ms=round(total_latency_ms, 2),
            cache_hit=False,
            model=meta_dict.get("model", "hybrid-llm-deeplink-v1"),
            cost_usd=meta_dict.get("cost_usd", 0.00035),
            fallback=meta_dict.get("fallback")
        )
    )


@app.get("/")
def serve_index():
    """Serves the interactive Galaxy Troubleshooting demo dashboard."""
    index_file = STATIC_DIR / "index.html"
    if index_file.exists():
        return FileResponse(index_file)
    return {"message": "Samsung Smart Guided Troubleshooting Engine API is running. Visit /docs for OpenAPI specs."}
