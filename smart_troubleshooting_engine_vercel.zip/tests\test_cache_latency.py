"""
Performance & Latency Test.
Verifies:
- P95 latency <= 300 ms on cached scenarios
- Semantic paraphrase cache hit rate >= 80%
"""

import time
import unittest
from app.cache.fast_cache import FastPathCache


class TestCacheLatency(unittest.TestCase):
    def setUp(self):
        self.cache = FastPathCache.get_instance()

    def test_p95_latency_under_300ms(self):
        query = "screen flickers and the battery dies fast"
        latencies = []

        for _ in range(50):
            t0 = time.perf_counter()
            res = self.cache.get(query)
            t1 = time.perf_counter()
            latencies.append((t1 - t0) * 1000.0)
            self.assertIsNotNone(res)

        latencies.sort()
        p95_idx = int(0.95 * len(latencies))
        p95_latency = latencies[p95_idx]

        print(f"\n[Benchmark] Fast-Path P95 Latency: {p95_latency:.3f} ms (Target: <= 300 ms)")
        self.assertLess(p95_latency, 300.0)

    def test_semantic_paraphrase_hit_rate(self):
        # Diverse unseen paraphrases across different registers
        test_paraphrases = [
            "my display is flashing rapidly and battery dying quick",
            "phone swipe gesture not working properly after installing new app",
            "battery drains overnight while phone is asleep",
            "phone got very sluggish and freezes after updating One UI",
            "camera taking blurry pictures in dark room and lagging"
        ]

        hits = 0
        for p in test_paraphrases:
            res = self.cache.get(p)
            if res is not None:
                hits += 1

        hit_rate = (hits / len(test_paraphrases)) * 100.0
        print(f"[Benchmark] Semantic Paraphrase Hit Rate: {hit_rate:.1f}% (Target: >= 80%)")
        self.assertGreaterEqual(hit_rate, 80.0)


if __name__ == "__main__":
    unittest.main()
