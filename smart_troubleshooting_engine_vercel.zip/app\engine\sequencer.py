"""
Action Sequencing Engine.
Enforces non-negotiable hierarchy constraint:
- Non-invasive / auto settings first
- Manual physical interventions second
- Critical / disruptive operations (restart, reset, firmware update) strictly ordered LAST.
"""

from typing import List
from app.schema import Action, actionCategory


def order_actions(actions: List[Action]) -> List[Action]:
    """
    Sorts actions by disruption level:
    1. auto (lowest disruption, single-tap settings fixes)
    2. manual (physical actions like cleaning ports, checking cables)
    3. critical (disruptive/irreversible actions like reboot, factory reset, firmware)
    Preserves relative order within each tier.
    """
    category_priority = {
        actionCategory.auto: 0,
        actionCategory.manual: 1,
        actionCategory.critical: 2
    }

    # Ensure each action has a category
    for act in actions:
        if act.category is None:
            act.category = actionCategory.manual
        elif isinstance(act.category, str):
            try:
                act.category = actionCategory(act.category)
            except ValueError:
                act.category = actionCategory.manual

    return sorted(actions, key=lambda a: category_priority.get(a.category, 1))
