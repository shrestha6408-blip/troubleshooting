const PRESETS = {
  navigation: {
    query: "The mobile phone swipe navigation moves up or down instead of left or right after downloading an app",
    siis: ""
  },
  screen_flicker: {
    query: "screen flickers and the battery dies fast",
    siis: ""
  },
  battery: {
    query: "Battery level drops rapidly overnight even when device is on standby",
    siis: ""
  },
  performance: {
    query: "my phone got slow after the update",
    siis: ""
  },
  camera: {
    query: "camera app lags and takes blurry photos in low light",
    siis: ""
  }
};

function selectPreset(key) {
  const p = PRESETS[key];
  if (p) {
    document.getElementById("queryInput").value = p.query;
    document.getElementById("siisInput").value = p.siis;
    executeTroubleshoot();
  }
}

async function executeTroubleshoot() {
  const query = document.getElementById("queryInput").value.trim();
  const siis = document.getElementById("siisInput").value.trim();
  const statusElem = document.getElementById("statusIndicator");

  if (!query) {
    alert("Please enter a device issue or select a preset.");
    return;
  }

  statusElem.textContent = "Processing diagnostic...";
  const startTime = performance.now();

  try {
    const res = await fetch("/v1/troubleshoot", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query: query, siis_response: siis || null })
    });

    if (!res.ok) {
      throw new Error(`API error ${res.status}`);
    }

    const data = await res.json();
    renderResponse(data);
    statusElem.textContent = "Plan generated.";
  } catch (err) {
    statusElem.textContent = "Error: " + err.message;
  }
}

function renderResponse(data) {
  const meta = data.meta || {};
  const latElem = document.getElementById("metricLatency");
  latElem.textContent = `${meta.latency_ms} ms`;
  latElem.style.color = meta.latency_ms <= 300 ? "#34d399" : "#f59e0b";

  const hitElem = document.getElementById("metricCacheHit");
  hitElem.textContent = meta.cache_hit ? "HIT (<300ms)" : "MISS (Cold)";
  hitElem.style.color = meta.cache_hit ? "#34d399" : "#94a3b8";

  document.getElementById("metricCost").textContent = `$${(meta.cost_usd || 0).toFixed(5)}`;
  document.getElementById("metricVariations").textContent = data.query_variations ? data.query_variations.length : 0;

  // Render variations
  const varList = document.getElementById("variationsList");
  varList.innerHTML = "";
  (data.query_variations || []).forEach(v => {
    const li = document.createElement("li");
    li.textContent = v;
    varList.appendChild(li);
  });

  // Render Results
  const resultsArea = document.getElementById("resultsArea");
  const contexts = data.response?.contexts || [];

  if (contexts.length === 0) {
    resultsArea.style.display = "block";
    document.getElementById("goalTitle").textContent = "No Direct Match Found";
    document.getElementById("goalHeading").textContent = "The reference knowledge base contained no viable solution.";
    document.getElementById("actionsContainer").innerHTML = `<div style="color: #94a3b8; font-size: 0.9rem;">Fallback metadata triggered: no_match. Please provide additional context.</div>`;
    return;
  }

  const primaryGoal = contexts[0];
  resultsArea.style.display = "block";
  document.getElementById("goalTitle").textContent = primaryGoal.title;
  document.getElementById("goalHeading").textContent = `${primaryGoal.goal} (Confidence: ${(primaryGoal.score * 100).toFixed(0)}%)`;

  const container = document.getElementById("actionsContainer");
  container.innerHTML = "";

  primaryGoal.actions.forEach((act, actIdx) => {
    const actCard = document.createElement("div");
    actCard.className = "action-card";

    let catClass = "badge-auto";
    if (act.category === "manual") catClass = "badge-manual";
    if (act.category === "critical") catClass = "badge-critical";

    let stepsHtml = "";
    let deeplinkHtml = "";

    (act.stepGroups || []).forEach(sg => {
      stepsHtml += "<ol class='step-list'>";
      (sg.steps || []).forEach(st => {
        stepsHtml += `<li>${st}</li>`;
      });
      stepsHtml += "</ol>";

      if (sg.actionableDeeplink && sg.actionableDeeplink.deeplink) {
        const dUri = sg.actionableDeeplink.deeplink;
        const dDesc = sg.actionableDeeplink.description;
        deeplinkHtml = `
          <button class="deeplink-btn" onclick='simulateDeeplink(${JSON.stringify(act.actionName)}, ${JSON.stringify(dUri)}, ${JSON.stringify(dDesc)}, ${JSON.stringify(sg.steps)})'>
            <span>&#9881;</span> One-Tap Settings: ${dUri}
          </button>
        `;
      }
    });

    actCard.innerHTML = `
      <div class="action-header">
        <strong style="color: #f1f5f9; font-size: 0.95rem;">${actIdx + 1}. ${act.actionName}</strong>
        <span class="badge ${catClass}">${act.category}</span>
      </div>
      <div style="font-size: 0.85rem; color: #38bdf8; margin-bottom: 0.5rem;"><em>${act.description}</em></div>
      ${stepsHtml}
      ${deeplinkHtml}
    `;

    container.appendChild(actCard);
  });
}

function simulateDeeplink(actionName, uri, description, steps) {
  const content = document.getElementById("phoneContent");
  content.innerHTML = `
    <div style="animation: fadeIn 0.3s ease-in-out;">
      <div style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 1rem; color: #38bdf8;">
        <span>&larr;</span>
        <span style="font-size: 0.8rem; font-weight: 600;">Settings</span>
      </div>
      <div class="screen-active-title">${actionName}</div>
      <div style="font-size: 0.75rem; color: #60a5fa; background: #172554; padding: 0.4rem 0.6rem; border-radius: 6px; margin-bottom: 1rem; word-break: break-all;">
        URI: ${uri}
      </div>
      <div style="font-size: 0.8rem; color: #94a3b8; margin-bottom: 1rem;">
        ${description}
      </div>
      <div style="border-top: 1px solid #1e293b; padding-top: 0.75rem;">
        <div style="font-size: 0.75rem; font-weight: 600; color: #64748b; margin-bottom: 0.5rem; text-transform: uppercase;">
          Interactive Screen Elements:
        </div>
        ${steps.map(s => `
          <div class="one-ui-item">
            <span>${s}</span>
            <span style="color: #34d399; font-size: 0.75rem;">Active</span>
          </div>
        `).join("")}
      </div>
    </div>
  `;
}
