"""
Data contract definition for Smart Guided Troubleshooting Engine.
Conforms strictly to Appendix A and Appendix B of Samsung Electronics specifications.
"""

from enum import Enum
from typing import Dict, List, Optional, Any
from pydantic import BaseModel, Field


class BaseDeeplink(BaseModel):
    deeplink: str


class Deeplink(BaseDeeplink):
    description: str
    message: Optional[str] = ""
    classes: Optional[Dict[str, str]] = None
    originalType: Optional[str] = None


class Condition(str, Enum):
    greater = "greater"
    equal = "equal"
    less = "less"


class ResultTypes(str, Enum):
    boolean = "boolean"
    intNum = "intNum"
    string = "str"
    floatNum = "float"


class actionCategory(str, Enum):
    auto = "auto"
    manual = "manual"
    critical = "critical"


class ValidationDeeplink(BaseDeeplink):
    key: str
    resultType: Optional[ResultTypes] = None
    condition: Optional[Condition] = None
    value: Optional[str] = None


class StepGroup(BaseModel):
    steps: List[str]
    validationDeeplink: Optional[ValidationDeeplink] = None
    actionableDeeplink: Optional[Deeplink] = None


class Action(BaseModel):
    actionName: str
    description: str
    stepGroups: List[StepGroup]
    category: Optional[actionCategory] = actionCategory.manual


class Goal(BaseModel):
    goal: str
    title: str
    actions: List[Action]
    score: float


class ContextDeeplinkResponse(BaseModel):
    """RAG response containing a list of Goal objects."""
    contexts: List[Goal] = []


# --- Top-Level API Request and Response Models (Appendix B) ---

class TroubleshootRequest(BaseModel):
    query: str = Field(..., description="Customer problem description in natural language")
    siis_response: Optional[str] = Field(None, description="Optional raw knowledge text from SIIS")


class ResponseMeta(BaseModel):
    latency_ms: float = Field(..., description="Processing latency in milliseconds")
    cache_hit: bool = Field(..., description="Whether served directly from cache")
    model: str = Field("hybrid-llm-deeplink-v1", description="Model or engine version")
    cost_usd: float = Field(0.0, description="Estimated inference cost in USD")
    fallback: Optional[str] = Field(None, description="Fallback metadata when no context matches")


class TroubleshootResponse(BaseModel):
    query: str
    query_variations: List[str] = Field(default_factory=list, description="8 to 10 distinct paraphrases across varied registers")
    response: ContextDeeplinkResponse
    meta: ResponseMeta
