"""
API Integration Tests for FastAPI service.
Tests:
- GET /health
- POST /v1/troubleshoot (Fast-Path Hit)
- POST /v1/troubleshoot (Cold Query with SIIS)
- POST /v1/troubleshoot (Fallback with no match)
"""

import unittest
from fastapi.testclient import TestClient
from app.main import app


class TestApiEndpoints(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)

    def test_health_endpoint(self):
        response = self.client.get("/health")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), {"status": "ok"})

    def test_troubleshoot_cached_scenario(self):
        payload = {
            "query": "screen flickers and the battery dies fast"
        }
        response = self.client.post("/v1/troubleshoot", json=payload)
        self.assertEqual(response.status_code, 200)
        data = response.json()
        
        # Verify structure matches Appendix B
        self.assertIn("query", data)
        self.assertIn("query_variations", data)
        self.assertIn("response", data)
        self.assertIn("meta", data)
        
        # Verify fast path latency constraint
        self.assertTrue(data["meta"]["cache_hit"])
        self.assertLess(data["meta"]["latency_ms"], 300.0)
        self.assertEqual(data["meta"]["cost_usd"], 0.0)

        # Verify deeplinks are present and valid
        contexts = data["response"]["contexts"]
        self.assertGreater(len(contexts), 0)
        first_action = contexts[0]["actions"][0]
        self.assertTrue(first_action["description"].startswith("It will"))
        deeplink_obj = first_action["stepGroups"][0]["actionableDeeplink"]
        self.assertIsNotNone(deeplink_obj)
        self.assertTrue(deeplink_obj["deeplink"].startswith("bixby://"))

    def test_troubleshoot_cold_with_siis(self):
        payload = {
            "query": "unusual vibration and screen issue",
            "siis_response": "Open Settings. Tap Display. Tap Motion smoothness and choose Standard 60Hz. Toggle off Adaptive brightness."
        }
        response = self.client.post("/v1/troubleshoot", json=payload)
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertIn("response", data)
        contexts = data["response"]["contexts"]
        self.assertGreater(len(contexts), 0)

    def test_no_viable_solution_fallback(self):
        payload = {
            "query": "completely unrelated cooking recipe query",
            "siis_response": ""
        }
        response = self.client.post("/v1/troubleshoot", json=payload)
        self.assertEqual(response.status_code, 200)
        data = response.json()
        # Fallback condition check: contexts empty and fallback metadata
        self.assertEqual(len(data["response"]["contexts"]), 0)
        self.assertEqual(data["meta"].get("fallback"), "no_match")


if __name__ == "__main__":
    unittest.main()
