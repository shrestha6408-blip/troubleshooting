"""
End-to-End Troubleshooting Pipeline.
Orchestrates:
Stage 0: Query Enrichment & Paraphrases
Stage 1: Structure Extraction
Stage 2: Deeplink Mapping & Action Ordering
Stage 3: Guardrail Validation
"""

import time
from typing import Dict, Any, Tuple
from app.schema import Goal, ContextDeeplinkResponse, actionCategory
from app.engine.enrichment import normalize_to_canonical, generate_query_variations
from app.engine.extractor import StructureExtractor
from app.engine.deeplink_matcher import DeeplinkCatalog
from app.engine.sequencer import order_actions
from app.engine.validators import validate_and_correct_goal


class TroubleshootingPipeline:
    def __init__(self):
        self.extractor = StructureExtractor()
        self.catalog = DeeplinkCatalog.get_instance()

    def process_query(self, query: str, siis_text: str = None) -> Tuple[Dict[str, Any], Dict[str, Any]]:
        """
        Executes cold query processing pipeline [0]-[2] + Validation.
        Returns (result_dict, meta_dict).
        """
        start_time = time.perf_counter()

        # [0] Query Enrichment
        canonical_query, topic = normalize_to_canonical(query)
        query_variations = generate_query_variations(query, canonical_query)

        # [1] Structure Extraction (LLM / Parsing)
        goals, extraction_meta = self.extractor.extract_structure(query, topic, siis_text)

        # Handle empty/fallback case
        if not goals:
            elapsed_ms = (time.perf_counter() - start_time) * 1000.0
            return {
                "query": query,
                "query_variations": query_variations,
                "response": {
                    "contexts": []
                }
            }, {
                "latency_ms": round(elapsed_ms, 2),
                "cache_hit": False,
                "model": extraction_meta.get("model", "pipeline-v1"),
                "cost_usd": extraction_meta.get("cost_usd", 0.0),
                "fallback": extraction_meta.get("fallback", "no_match")
            }

        # [2] Deeplink Mapping & Action Ordering
        processed_goals = []
        for goal in goals:
            # Order actions: auto first -> manual second -> critical last
            ordered = order_actions(goal.actions)

            for act in ordered:
                # Resolve deeplinks for auto actions
                if act.category == actionCategory.auto:
                    for sg in act.stepGroups:
                        matched_link = self.catalog.match_deeplink(act.actionName, sg.steps)
                        sg.actionableDeeplink = matched_link
                else:
                    # Manual and critical actions do not carry actionable deeplinks
                    for sg in act.stepGroups:
                        sg.actionableDeeplink = None

            goal.actions = ordered
            # Apply guardrail validators
            validated_goal = validate_and_correct_goal(goal)
            processed_goals.append(validated_goal)

        elapsed_ms = (time.perf_counter() - start_time) * 1000.0

        result_dict = {
            "query": query,
            "query_variations": query_variations,
            "response": {
                "contexts": [g.model_dump() for g in processed_goals]
            }
        }

        meta_dict = {
            "latency_ms": round(elapsed_ms, 2),
            "cache_hit": False,
            "model": extraction_meta.get("model", "hybrid-llm-deeplink-v1"),
            "cost_usd": extraction_meta.get("cost_usd", 0.00035)
        }

        return result_dict, meta_dict
