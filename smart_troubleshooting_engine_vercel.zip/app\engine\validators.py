"""
Validation and Programmatic Correction Guardrails.
Enforces non-negotiable operational constraints:
- Zero URL Leaks (strips http/https/www/markdown links)
- Strict Description Syntax (5 to 7 words, starting with 'It will')
- Title constraints (2 to 3 words, sentence case)
- Goal syntax ('Follow these steps to perform this <Topic> Troubleshooting/Configuration')
- Action ordering (auto -> manual -> critical last)
"""

import re
from typing import List, Optional
from app.schema import Goal, Action, StepGroup, actionCategory, ContextDeeplinkResponse

# URL Regex pattern targeting all http, https, www, domain-like patterns, and markdown links
URL_PATTERN = re.compile(
    r'(?:https?://|www\.)[^\s<>"]+|\[([^\]]+)\]\((?:https?://|www\.)[^\s<>"]+\)',
    re.IGNORECASE
)
MARKDOWN_LINK_PATTERN = re.compile(r'\[([^\]]+)\]\([^\)]+\)')


def scrub_urls(text: str) -> str:
    """Programmatically scrub all URLs and markdown links from text."""
    if not text:
        return ""
    # Replace markdown links with their anchor text
    cleaned = MARKDOWN_LINK_PATTERN.sub(r'\1', text)
    # Strip any remaining URLs
    cleaned = URL_PATTERN.sub('', cleaned)
    # Clean up double spaces or orphan punctuation
    cleaned = re.sub(r'\s+', ' ', cleaned).strip()
    return cleaned


def normalize_title(title: str, topic: str = "Device Issue") -> str:
    """Enforce 2 to 3 words, sentence case identifying the core issue."""
    words = re.findall(r'\b[A-Za-z0-9]+\b', title)
    if len(words) < 2:
        words = re.findall(r'\b[A-Za-z0-9]+\b', f"{title} fix")
    if len(words) > 3:
        words = words[:3]
    
    # Capitalize first word, keep rest lower (sentence case)
    result = " ".join(words)
    if len(result) > 0:
        result = result[0].upper() + result[1:].lower()
    return result


def normalize_goal(goal: str, topic: str = "Device Issue") -> str:
    """Enforce exact syntax: Follow these steps to perform this <Topic> Troubleshooting"""
    prefix = "Follow these steps to perform this "
    suffix_troubleshoot = " Troubleshooting"
    suffix_config = " Configuration"

    if goal.startswith(prefix) and (goal.endswith(suffix_troubleshoot) or goal.endswith(suffix_config)):
        return goal
    
    # Extract topic or clean existing
    clean_topic = re.sub(r'^(Follow these steps to perform this|Troubleshoot|Fix|Configure)\s*', '', goal, flags=re.IGNORECASE)
    clean_topic = re.sub(r'\s*(Troubleshooting|Configuration)$', '', clean_topic, flags=re.IGNORECASE).strip()
    if not clean_topic:
        clean_topic = topic
    
    # Title-case the topic
    clean_topic = " ".join(w.capitalize() for w in clean_topic.split()[:3])
    return f"Follow these steps to perform this {clean_topic} Troubleshooting"


def normalize_description(desc: str, action_name: str = "") -> str:
    """
    Enforce: Exactly 5 to 7 words, starting with 'It will',
    explaining concrete benefit in plain language.
    """
    cleaned = scrub_urls(desc)
    words = re.findall(r'\b[A-Za-z0-9\']+\b', cleaned)
    
    # Ensure starts with "It will"
    if len(words) < 2 or words[0].lower() != "it" or words[1].lower() != "will":
        # Build benefit words from action_name
        action_words = [w.lower() for w in re.findall(r'\b[A-Za-z0-9]+\b', action_name)]
        if action_words:
            core = " ".join(action_words[:4])
            words = ["It", "will", "optimize", "device", "settings"]
        else:
            words = ["It", "will", "resolve", "device", "settings"]

    words[0] = "It"
    words[1] = "will"

    # Enforce word count between 5 and 7 words
    if len(words) < 5:
        padding = ["settings", "properly", "now"]
        while len(words) < 5:
            words.append(padding.pop(0) if padding else "efficiently")
    elif len(words) > 7:
        words = words[:6]  # 6 words is right in the 5-7 sweet spot

    return " ".join(words)


def validate_and_correct_goal(goal: Goal) -> Goal:
    """Validate and sanitize a single Goal object against all contract rules."""
    goal.goal = normalize_goal(goal.goal, goal.title or "Device")
    goal.title = normalize_title(goal.title)
    goal.score = max(0.0, min(1.0, float(goal.score)))

    # Process Actions
    for action in goal.actions:
        action.actionName = scrub_urls(action.actionName).title()
        action.description = normalize_description(action.description, action.actionName)
        
        # Validate category rules
        if action.category == actionCategory.manual:
            # Manual physical interventions cannot carry actionable deeplinks
            for sg in action.stepGroups:
                sg.actionableDeeplink = None
        
        # Scrub URLs in all step strings
        for sg in action.stepGroups:
            sg.steps = [scrub_urls(s) for s in sg.steps if scrub_urls(s)]

    return goal
