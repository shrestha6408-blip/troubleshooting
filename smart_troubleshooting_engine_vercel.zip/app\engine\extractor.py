"""
Structure Extraction Engine (Phase 1).
Parses unstructured customer-care reference text (SIIS) into a structured
Goal object containing atomic steps and action categories.
Enforces the 'One Action = One Screen' rule, zero hallucinations,
and strict fallback handling when no viable solution exists.
"""

import json
import re
from typing import List, Optional, Tuple, Dict, Any
from app.config import SIIS_FILE
from app.schema import Goal, Action, StepGroup, actionCategory
from app.engine.validators import normalize_goal, normalize_title, normalize_description, scrub_urls
from app.engine.llm_service import LLMService


class StructureExtractor:
    def __init__(self):
        self.siis_kb: Dict[str, str] = {}
        self.llm_service = LLMService()
        self.load_siis_kb()

    def load_siis_kb(self):
        """Loads pre-cleaned SIIS knowledge base."""
        if SIIS_FILE.exists():
            with open(SIIS_FILE, "r", encoding="utf-8") as f:
                self.siis_kb = json.load(f)

    def extract_structure(self, query: str, topic: str, siis_text: Optional[str] = None) -> Tuple[List[Goal], Dict[str, Any]]:
        """
        Extracts structured Goal objects from reference text.
        Returns (goals, extraction_meta).
        """
        # If no SIIS text provided, attempt to locate relevant SIIS entry from KB
        if not siis_text or not siis_text.strip():
            siis_text = self._find_relevant_siis(query)

        # Constraint 3: No Hallucinated Steps. If reference text is empty or has no viable solution:
        if not siis_text or not siis_text.strip():
            return [], {
                "model": "no-context-fallback",
                "cost_usd": 0.0,
                "latency_ms": 1.0,
                "fallback": "no_match"
            }

        # Try LLM extraction first if configured
        parsed_llm, meta = self.llm_service.generate_plan(query, siis_text)
        if parsed_llm and "contexts" in parsed_llm and len(parsed_llm["contexts"]) > 0:
            goals = []
            for g_data in parsed_llm["contexts"]:
                try:
                    goal_obj = self._build_goal_from_dict(g_data, topic)
                    goals.append(goal_obj)
                except Exception:
                    pass
            if goals:
                return goals, meta

        # Fallback to high-fidelity deterministic SIIS parser
        goals = self._deterministic_extract(query, topic, siis_text)
        meta["model"] = "deterministic-siis-extractor"
        return goals, meta

    def _find_relevant_siis(self, query: str) -> Optional[str]:
        """Matches user query to stored SIIS reference texts."""
        q_lower = query.lower()
        if "swipe" in q_lower or "navigation" in q_lower or "gesture" in q_lower:
            return self.siis_kb.get("siis_navigation_swipe")
        if "flicker" in q_lower or "blink" in q_lower:
            return self.siis_kb.get("siis_display_flicker")
        if "battery" in q_lower or "drain" in q_lower or "power" in q_lower:
            return self.siis_kb.get("siis_battery_fast_drain")
        if "slow" in q_lower or "lag" in q_lower or "update" in q_lower:
            return self.siis_kb.get("siis_phone_sluggish_performance")
        if "camera" in q_lower or "blurry" in q_lower:
            return self.siis_kb.get("siis_camera_freeze_blurry")
        return None

    def _deterministic_extract(self, query: str, topic: str, siis_text: str) -> List[Goal]:
        """
        Parses sentences of SIIS text and groups them into screen-specific Actions.
        Guarantees 'One Action = One Screen', correct categorization, and rule compliance.
        """
        sentences = [s.strip() for s in re.split(r'\.\s+', siis_text) if s.strip()]
        if not sentences:
            return []

        actions: List[Action] = []
        screen_buckets: Dict[str, List[str]] = {}

        # Screen detection keywords for grouping
        for s in sentences:
            s_clean = scrub_urls(s)
            s_lower = s_clean.lower()
            
            if "navigation bar" in s_lower or "gesture" in s_lower or "buttons" in s_lower:
                screen = "Configure Navigation Bar Settings"
            elif "motion smoothness" in s_lower or "refresh rate" in s_lower:
                screen = "Adjust Motion Smoothness Refresh Rate"
            elif "adaptive brightness" in s_lower or "brightness" in s_lower:
                screen = "Configure Adaptive Brightness Setting"
            elif "background usage limits" in s_lower or "sleeping apps" in s_lower:
                screen = "Configure Background Usage Limits"
            elif "power saving" in s_lower:
                screen = "Enable Power Saving Mode"
            elif "optimize now" in s_lower or "device care" in s_lower:
                screen = "Optimize Memory In Device Care"
            elif "ram plus" in s_lower:
                screen = "Adjust RAM Plus Virtual Memory"
            elif "restart" in s_lower or "reboot" in s_lower:
                screen = "Restart Phone To Clear Cache"
            elif "camera" in s_lower and "reset" in s_lower:
                screen = "Reset Camera App Configuration"
            elif "clear cache" in s_lower:
                screen = "Manage Camera App Storage Cache"
            else:
                screen = "Configure Device Settings"

            if screen not in screen_buckets:
                screen_buckets[screen] = []
            
            # Format as imperative UI step
            if not s_clean.endswith("."):
                s_clean += "."
            screen_buckets[screen].append(s_clean)

        for screen_name, steps in screen_buckets.items():
            # Determine category
            lower_name = screen_name.lower()
            if any(crit in lower_name for crit in ["restart", "reboot", "factory reset", "format", "firmware"]):
                category = actionCategory.critical
            elif any(man in lower_name for man in ["clean port", "hardware", "service center", "cable"]):
                category = actionCategory.manual
            else:
                category = actionCategory.auto

            # Generate description strictly adhering to 5-7 words starting with "It will"
            desc = normalize_description("", screen_name)

            action = Action(
                actionName=screen_name,
                description=desc,
                category=category,
                stepGroups=[
                    StepGroup(
                        steps=steps,
                        actionableDeeplink=None,
                        validationDeeplink=None
                    )
                ]
            )
            actions.append(action)

        goal = Goal(
            goal=normalize_goal("", topic),
            title=normalize_title(f"{topic} settings"),
            actions=actions,
            score=0.94
        )
        return [goal]

    def _build_goal_from_dict(self, d: Dict[str, Any], topic: str) -> Goal:
        actions = []
        for a_data in d.get("actions", []):
            step_groups = []
            for sg_data in a_data.get("stepGroups", []):
                step_groups.append(StepGroup(
                    steps=[scrub_urls(s) for s in sg_data.get("steps", [])],
                    actionableDeeplink=None,
                    validationDeeplink=None
                ))
            
            raw_cat = a_data.get("category", "auto")
            cat = actionCategory.auto
            if raw_cat in ["manual", "critical", "auto"]:
                cat = actionCategory(raw_cat)

            actions.append(Action(
                actionName=scrub_urls(a_data.get("actionName", "Configure Settings")).title(),
                description=normalize_description(a_data.get("description", ""), a_data.get("actionName", "")),
                category=cat,
                stepGroups=step_groups
            ))

        return Goal(
            goal=normalize_goal(d.get("goal", ""), topic),
            title=normalize_title(d.get("title", f"{topic} issue")),
            actions=actions,
            score=float(d.get("score", 0.90))
        )
