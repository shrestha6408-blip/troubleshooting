"""
Configuration settings for Smart Guided Troubleshooting Engine.
"""

import os
from pathlib import Path

# Paths
BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
DEEPLINKS_FILE = DATA_DIR / "deeplinks.json"
QUERIES_FILE = DATA_DIR / "queries.json"
SIIS_FILE = DATA_DIR / "siis_responses.json"
SAMPLES_DIR = DATA_DIR / "samples"
CACHE_STORAGE_FILE = BASE_DIR / "cache_store.json"

# Operational Thresholds
CACHE_HIT_LATENCY_MAX_MS = 300.0  # Constraint: Fast-Path P95 <= 300 ms
COLD_QUERY_LATENCY_MAX_MS = 8000.0  # Constraint: Cold path P95 <= 8000 ms
CONFIDENCE_THRESHOLD = 0.60
TARGET_QUERY_VARIATIONS = 10

# API Keys & Models
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
LLM_MODEL_NAME = os.getenv("LLM_MODEL_NAME", "gemini-2.5-flash")
ESTIMATED_PROMPT_TOKEN_COST_PER_M = 0.15   # USD per 1M tokens
ESTIMATED_COMPLETION_TOKEN_COST_PER_M = 0.60  # USD per 1M tokens
